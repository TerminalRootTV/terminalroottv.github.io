#!/usr/bin/env bash

feh --bg-scale $HOME/dragonflybsd.jpg
xrdb $HOME/.Xresources
export LANG=pt_BR.UTF-8
setxkbmap -model abnt2 -layout br -variant abnt2
bash $HOME/.fehbg

g=( $(herbstclient monitor_rect 0) )
x=${g[0]}
y=${g[1]}
w=${g[2]}
h=18

A="%{F#FFFFFF}"
B="%{F#9fbc00}"
C="%{F#4d4d4d}"

bgA="%{B#9fbc00}"
bgB="%{B#4d4d4d}"
bgC="%{B#101010}"
bgO="%{B#000000}"

herbstclient pad 0 $h

desktop(){
	for i in $(herbstclient tag_status 0); do
		n=$(echo $i | tr -d '.:#')
		case "$i" in
			"$(echo $i | grep '\#')") cor="$A";bg="$bgA" ;;
			"$(echo $i | grep '\:')") cor="$B";bg="$bgB" ;;
			"$(echo $i | grep '\.')") cor="$C";bg="$bgC" ;;
		esac

		echo -en "|${cor}${bg} ${n} ${bgO}"
	done
	echo -en "|"

        id=$(xdotool getactivewindow)
        pid=$(xdotool getwindowpid "$id")
        title=$(ps -U $USER | grep "$pid" | awk '{print $5}' | tr '\-' ' ' | sed 's/grep//g')
	title=$(echo ${title^})

	if [[ ! -z "$pid" ]]; then
		
		echo -en "%{c}${B}| $title |"
	else
		echo -en "%{c}> ${HOSTNAME^} <"
	fi

	echo -en "%{r}| ${A}$(date +%d-%m-%Y.%H:%m)"
}

while : ; do

	echo "%{l}$(desktop)"

done | lemonbar -g ${w}x${h}+${x}+${y} -f "UbuntuMono-R"

