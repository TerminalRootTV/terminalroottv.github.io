#ifndef EXAMPLE_HELLOWORD_H
#define EXAMPLE_HELLOWORD_H

#include <iostream>

class HelloWorld {
	public:
		HelloWorld();
		virtual ~HelloWorld();

	protected:
		virtual void my_world();

	public:
		void run();

};

#endif
