#include <crow.h>

std::string url_decode(const std::string& str){
  std::ostringstream decoded;
  for(size_t i = 0; i < str.size(); ++i){
    if(str[i] == '%' && i + 2 < str.size()){
      std::istringstream hex(str.substr(i + 1, 2));
      int value;
      if(hex >> std::hex >> value){
        decoded << static_cast<char>(value);
        i += 2;
      }
    }else if (str[i] == '+'){
      decoded << ' ';
    }else{
      decoded << str[i];
    }
  }
  return decoded.str();
}

std::unordered_map<std::string, std::string> parse_form_data(const std::string& body){
  std::unordered_map<std::string, std::string> result = {};
  std::istringstream ss(body);
  std::string pair = {};

  while(std::getline(ss, pair, '&')){
    const auto pos = pair.find('=');
    if(pos != std::string::npos){
      const std::string key = url_decode(pair.substr(0, pos));
      const std::string value = url_decode(pair.substr(pos + 1));
      result[key] = value;
    }
  }

  return result;
}

int main(){
    crow::SimpleApp app;

    CROW_ROUTE(app, "/")([](){
        const std::string title = "Crow C++, MySQL, TaildwindCSS";
        auto page = crow::mustache::load("index.html");
        crow::mustache::context ctx({{ "title", title }});
        return page.render(ctx);
    });

    CROW_ROUTE(app, "/login").methods("GET"_method, "POST"_method)([](const crow::request& req){
        const std::string name = "Marcos Oliveira";
        auto page = crow::mustache::load("login.html");

        const std::string user = parse_form_data(req.body)["mid"];
        const std::string pass = parse_form_data(req.body)["mpass"];

        std::string error = {};

        if(user == "marcos" && pass == "teste123@"){
          auto response = crow::response(302);
          response.set_header("Location", "/crow/");
          return response;
        }else{
          if(req.body != ""){
            error = "Falha ao logar.";
          }
        }

        crow::mustache::context ctx({{ "error", error } });
        return crow::response(400, page.render(ctx));
    });

    app.port(18080).multithreaded().run();
}
