#pragma once

#include <crow.h>
#include <unordered_set>
#include <memory>

class ToDo {
  const std::string hash = "5asd55s5fw";
  std::unordered_set<std::string> active_sessions;
  std::string user;

  protected:
    std::string encode(std::string s);
    bool is_authenticated(const crow::request& req);
    std::string url_decode(const std::string& str);
    std::unordered_map<std::string, std::string> 
      parse_form_data(const std::string& body);

  void root();
  void login();
  void logout();

  crow::SimpleApp app;

  public:
    ToDo();
    void run();
};
