#include "todo.hpp"

ToDo::ToDo(){
  user = error = {};
  connect = mysql_init(NULL);

  if(!connect){
    log("Falha ao CONECTAR ao MySQL.");
    std::exit(1);
  }

  connect = mysql_real_connect(
    connect,
    "localhost",
    "root",
    "654321",
    "cpp",0, NULL, 0
  );

  if(!connect){
    log("Falha ao LOGAR no MySQL");
    std::exit(1);
  }
}

std::string ToDo::encode(std::string s){
  for(char& c : s){
    ++c;
  }
  return s;
}

bool ToDo::is_authenticated(const crow::request& req) {
  auto cookies = req.get_header_value("Cookie");
  if (cookies.empty()) return false;

  // Parse simples do cookie (em produção, use uma biblioteca mais robusta)
  std::string session_prefix = "session_id=";
  size_t pos = cookies.find(session_prefix);
  if (pos == std::string::npos) return false;

  pos += session_prefix.length();
  size_t end_pos = cookies.find(";", pos);
  if (end_pos == std::string::npos) end_pos = cookies.length();

  std::string session_id = cookies.substr(pos, end_pos - pos);
  return active_sessions.find(session_id) != active_sessions.end();
}


std::string ToDo::url_decode(const std::string& str){
  std::ostringstream decoded;
  for(size_t i = 0; i < str.size(); ++i){
    if(str[i] == '%' && i + 2 < str.size()){
      std::istringstream hex(str.substr(i + 1, 2));
      int value;
      if(hex >> std::hex >> value){
        decoded << static_cast<char>(value);
        i += 2;
      }
    }else if (str[i] == '+'){
      decoded << ' ';
    }else{
      decoded << str[i];
    }
  }
  return decoded.str();
}

std::unordered_map<std::string, std::string> ToDo::parse_form_data(const std::string& body){
  std::unordered_map<std::string, std::string> result = {};
  std::istringstream ss(body);
  std::string pair = {};

  while(std::getline(ss, pair, '&')){
    const auto pos = pair.find('=');
    if(pos != std::string::npos){
      const std::string key = url_decode(pair.substr(0, pos));
      const std::string value = url_decode(pair.substr(pos + 1));
      result[key] = value;
    }
  }

  return result;
}

void ToDo::root(){
    CROW_ROUTE(app, "/")([this](const crow::request& req){

        if(!is_authenticated(req)){
          auto response = crow::response(302);
          response.set_header("Location", "/crow/login");
          return response;
        }

        auto page = crow::mustache::load("index.html");
        crow::mustache::context ctx({{ "user", user }});
        //return page.render(ctx);
        return crow::response(400, page.render(ctx));
    });
}


void ToDo::login(){
    CROW_ROUTE(app, "/login").methods("GET"_method, "POST"_method)([this](const crow::request& req){

        if(is_authenticated(req)){
          auto response = crow::response(302);
          response.set_header("Location", "/crow/");
          return response;
        }

        const std::string name = "Marcos Oliveira";
        auto page = crow::mustache::load("login.html");

        user = parse_form_data(req.body)["mid"];
        const std::string pass = parse_form_data(req.body)["mpass"];

        if(auth(user, pass)){
          auto response = crow::response(302);

          const std::string session_token = encode(user + hash);
          active_sessions.insert(session_token);
          response.set_header("Set-Cookie", "session_id=" + session_token + "; Path=/crow/; HttpOnly; Max-Age=3600");

          response.set_header("Location", "/crow/");
          return response;
        }else{
          if(req.body != ""){
            error = "Falha ao logar.";
          }
        }

        crow::mustache::context ctx({ {"user", user} , { "error", error } });
        error.clear();
        return crow::response(400, page.render(ctx));
    });
}


void ToDo::logout(){
    CROW_ROUTE(app, "/logout")([this](const crow::request& req){
        auto cookies = req.get_header_value("Cookie");
        if (!cookies.empty()) {
          std::string session_prefix = "session_id=";
          size_t pos = cookies.find(session_prefix);
          if (pos != std::string::npos) {
            pos += session_prefix.length();
            size_t end_pos = cookies.find(";", pos);
            if (end_pos == std::string::npos) end_pos = cookies.length();

            std::string session_id = cookies.substr(pos, end_pos - pos);
            active_sessions.erase(session_id);
          }
        }

        auto response = crow::response(302);
        response.set_header("Location", "/crow/login");
        response.set_header("Set-Cookie", "session_id=; Path=/crow/; HttpOnly; Max-Age=0");
        return response;
    });
}


void ToDo::run(){
  root();
  login();
  logout();
  app.port(18080).multithreaded().run();
}
