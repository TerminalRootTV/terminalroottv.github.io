#include "todo.hpp"

ToDo::~ToDo(){
  mysql_close(connect);
}

std::string ToDo::datetime(){
  std::time_t t = std::time(nullptr);
  std::tm local_tm = *std::localtime(&t);
  std::ostringstream oss;
  oss << std::put_time(&local_tm, "%d/%m/%Y %H:%M:%S");
  const std::string out = oss.str();
  return out;
}

void ToDo::log(const std::string& msg){
  std::ofstream logfile("/var/www/html/crow/server.log", std::ios::app);
  logfile << datetime() << " " << msg + '\n';
}

bool ToDo::auth(const std::string& user, const std::string& pass){
  std::string query = "SELECT 1 FROM login WHERE user = '" + user + "' AND pass = SHA2('" + pass + "', 256) LIMIT 1";
   
  if(mysql_query(connect, query.c_str())){
    log("Falha ao EXECUTAR a consulta.");
    return false;
  }

  store_update();

  bool ok =mysql_num_rows(res) > 0;
  
  mysql_free_result(res);
  if(ok) select_user();

  return ok;
}

void ToDo::store_update(){
  res = mysql_store_result(connect);
  if(!res){
    log("Falha ao OBTER o resultado");
  }
}

void ToDo::select_user(){
  std::string query = "SELECT name FROM login WHERE user = '" + user + "'";
  if(mysql_query(connect, query.c_str())){
    log("Falha ao EXECUTAR a consulta.");
  }
   
  store_update();
  MYSQL_ROW row = mysql_fetch_row(res);
  if(row && row[0]){
      this->user = row[0];
  }else{
    log("Nenhum resultado encontrado.");
  }

  mysql_free_result(res);
}
