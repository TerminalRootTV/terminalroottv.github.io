#include "todo.hpp"

int main(){
  auto todo = std::make_unique<ToDo>();
  todo->run();
}
