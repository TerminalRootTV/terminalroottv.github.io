document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".edit-link").forEach(link => {
    link.addEventListener("click", e => {
      e.preventDefault();

      const form = document.getElementById("task-form");
      const li = e.target.closest("li");
      const id = li.dataset.id;
      const text = li.childNodes[0].textContent.trim();

      form.action = `/crow/update/${id}`;
      form.innerHTML = `
            <input type="text" name="edittask" class="newtask" value="${text}" maxlength="512" required>
            <button type="submit" class="btn-edittask">Editar tarefa</button>
          `;
    });
  });
});
