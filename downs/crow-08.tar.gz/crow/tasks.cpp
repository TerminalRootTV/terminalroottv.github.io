#include "todo.hpp"

void ToDo::insert(){
    CROW_ROUTE(app, "/insert").methods("GET"_method, "POST"_method)([this](const crow::request& req){

        if(user.empty()){
          auto response = crow::response(302);
          response.set_header("Location", "/crow/");
          return response;
        }

        std::string task = parse_form_data(req.body)["newtask"];

        if(!create_task(task) || task.empty()){
          crow::mustache::context ctx({ {"user", user} , { "taskin", "Erro ao inserir a tarefa" } });
          auto page = crow::mustache::load("index.html");
          return crow::response(400, page.render(ctx));         
        }


        auto response = crow::response(302);
        response.set_header("Location", "/crow/");
        return response;
    });
}

bool ToDo::create_task(const std::string& task){

  if(task.empty()) return false;

  std::string query = "INSERT INTO tasks (task) VALUES ('" + task + "')";
   
  if(mysql_query(connect, query.c_str()) != 0){
    log("Falha ao INSERIR dados.");
    return false;
  }

  unsigned long affected = mysql_affected_rows(connect);
  return affected > 0;
}


void ToDo::update(){
    CROW_ROUTE(app, "/update/<int>")
      .methods("GET"_method, "POST"_method)
      ([this](const crow::request& req, int id){

        if(user.empty()){
          auto response = crow::response(302);
          response.set_header("Location", "/crow/");
          return response;
        }

        std::string edittask = parse_form_data(req.body)["edittask"];

        if(!updel(id, edittask)){
          log("Falha ao EDITAR a tarefa.");
        }

        auto response = crow::response(302);
        response.set_header("Location", "/crow/");
        return response;
    });
}

void ToDo::delete_task(){
    CROW_ROUTE(app, "/delete/<int>")
      .methods("GET"_method, "POST"_method)
      ([this](int id){

        if(user.empty()){
          auto response = crow::response(302);
          response.set_header("Location", "/crow/");
          return response;
        }

        if(!updel(id)){
          log("Falha ao DELETAR a tarefa.");
        }

        auto response = crow::response(302);
        response.set_header("Location", "/crow/");
        return response;
    });
}
