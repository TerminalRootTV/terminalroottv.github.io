#pragma once

#include <crow.h>
#include <unordered_set>
#include <memory>
#include <mysql/mysql.h>
#include <fstream>

class ToDo {
  const std::string hash = "5asd55s5fw";
  std::unordered_set<std::string> active_sessions;
  std::string user, error;
  std::vector<std::pair<std::string, std::string>> tasks;

  MYSQL * connect;
  MYSQL_RES * res;

  protected:
    std::string encode(std::string s);
    bool is_authenticated(const crow::request& req);
    std::string url_decode(const std::string& str);
    std::unordered_map<std::string, std::string> 
      parse_form_data(const std::string& body);

  void log(const std::string&);
  std::string datetime();

  bool auth(const std::string&, const std::string&);
  void store_update();
  void select_user();
  bool create_task(const std::string& task);
  void select_tasks();
  bool updel(int id, const std::string& task = {});

  void root();
  void login();
  void logout();
  void insert();
  void update();
  void delete_task();

  crow::SimpleApp app;

  public:
    ToDo();
    ~ToDo();
    void run();
};
