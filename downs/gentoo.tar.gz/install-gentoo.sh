#!/bin/bash
# Script para Instalação do Gentoo

# Declarando variáveis
Gr="\e[32;1m"
Bl="\e[34;1m"
OfC="\e[m"

# Testando a conexão com a internet
echo -en " $Gr*$OfC Testando a conexao com a Internet ...\t\t"
[[ $(ping -c 4 www.terminalroot.com.br) ]] && echo -e "$Bl[$Gr ok $Bl]$OfC" || echo "Sem conexao a internet." && exit 1



exit 0
