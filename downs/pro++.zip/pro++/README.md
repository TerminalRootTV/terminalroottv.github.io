# Pro++
> Command to create C++ projects with SFML (temporarily: In the future it will cover more libraries, example: Raylib, OpenGL(with GLFW), Dear ImGui(with OpenGL and GLFW), SDL(2 and 3), SFML3,...)

---

## Compile and install
> Optional dependency is [Terlang](https://github.com/terroo/terlang) to build and install, but you can compile and install manually if you want.

```bash
wget https://terminalroot.com.br/downs/pro++.zip
unzip pro++.zip
cd pro++
ter build.ter
ter install.ter
```

---

## Using
```bash
pro++ "My Project"
cd MyProject
ter build.ter
```

> If you want to uninstall: `sudo rm /usr/local/bin/pro++`.
