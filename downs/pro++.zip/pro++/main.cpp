#include "propp.hpp"

int main(int const argc, char* const* argv){

  if(argc <= 1){
    std::cerr << "Enter the class name.\n";
    return EXIT_FAILURE;
  }

  auto pro = std::make_unique<ProPP>(argc, argv);
  pro->run();

  return EXIT_SUCCESS;
}
