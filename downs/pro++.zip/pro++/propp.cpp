#include "propp.hpp"

ProPP::ProPP(int const argc, char* const* argv) 
  : title(argv[1]){

    classname = title;
    filename = str_to_lower(title);

    if(has_space(argv[1])){
      change_space(classname, "");
      change_space(filename, "-");
    }

    dir = classname;

    if(std::filesystem::exists(dir)){
      std::cerr << "Error. Project/Directory already exists.\n";
      std::exit(65);
    }

    std::filesystem::create_directory(dir);

    set_files();
  }

const std::string ProPP::str_to_lower(const std::string& str) {
  std::string result = str;
  std::transform(result.begin(), result.end(), result.begin(),
      [](unsigned char c) { return std::tolower(c); });
  return result;
}

bool ProPP::has_space(const std::string& str) {
  return str.find(' ') != std::string::npos;
}

void ProPP::change_space(std::string& str, const std::string& c) {
  size_t pos = 0;
  while ((pos = str.find(' ', pos)) != std::string::npos) {
    str.replace(pos, 1, c);
    pos += c.length();
  }
}

bool ProPP::can_create(const std::filesystem::path& dir) {
  auto path = dir.parent_path();
  if (path.empty()){ path = "."; }// diretório atual
  return std::filesystem::exists(path) &&
    (std::filesystem::status(path).permissions() & std::filesystem::perms::owner_write) != std::filesystem::perms::none;
}

void ProPP::run(){
  path_header = classname,
              path_cpp = classname, 
              path_main = classname, 
              path_build = classname;

  path_header /= filename + ".hpp";
  path_cpp /= filename + ".cpp";
  path_build /= "build.ter";
  path_main /= "main.cpp";

  std::ofstream fileheader(path_header);
  std::ofstream filecpp(path_cpp);
  std::ofstream build(path_build);
  std::ofstream maincpp(path_main);

  if(fileheader.is_open() && filecpp.is_open() && build.is_open() && maincpp.is_open()) {
    fileheader << header_file;
    filecpp << cpp_file;
    build << build_file;
    maincpp << main_file;

    fileheader.close();
    filecpp.close();
    build.close();
    maincpp.close();

  }else{

    std::cerr << "Failed to create project.\n";
    std::exit(EXIT_FAILURE);
  }
}

void ProPP::set_files(){
  header_file =
    "#pragma once\n\n"
    "#include <SFML/Graphics.hpp>\n"
    "#include <memory>\n\n"
    "class " + classname + " {\n"
    "  sf::RenderWindow window;\n"
    "  void events(), draw();\n\n"
    "  public:\n"
    "    " + classname + "();\n"
    "    void run();\n"
    "};\n";

  cpp_file =
    "#include \"" + filename + ".hpp" + "\"\n"
    "\n"
    "" + classname + "::" + classname + "() : window(\n"
    "    sf::VideoMode(1280,720),\n"
    "    \"SFML " + title + "\",\n"
    "    sf::Style::Titlebar | sf::Style::Close){\n"
    "}\n"
    "\n"
    "void " + classname + "::events(){\n"
    "  auto event = std::make_unique<sf::Event>();\n"
    "  while(window.pollEvent(*event)){\n"
    "    if(event->type == sf::Event::Closed){\n"
    "      window.close();\n"
    "    }\n"
    "  }\n"
    "}\n"
    "\n"
    "void " + classname + "::draw(){\n"
    "  window.clear();\n"
    "  window.display();\n"
    "}\n"
    "\n"
    "void " + classname + "::run(){\n"
    "  while(window.isOpen()){\n"
    "    events();\n"
    "    draw();\n"
    "  }\n"
    "}";



  main_file =
    "#include \"" + filename + ".hpp\"\n\n"

    "int main(){\n"
    "  auto obj = std::make_unique<" + classname + ">();\n"
    "  obj->run();\n"
    "  return EXIT_SUCCESS;\n"
    "}\n";


  build_file = ""
    "auto flags = \"-g -Wall -Werror -Wpedantic -fsanitize=address\"\n"
    "flags = \"-Ofast\"\n"
    "\n"
    "auto build = \"g++ \" + flags + \" *.cpp -lsfml-graphics -lsfml-window -lsfml-system\"\n"
    "output(build)\n"
    "\n"
    "exec(build)\n"
    "exec(\"./a.out 2>/dev/null\")\n";
}
