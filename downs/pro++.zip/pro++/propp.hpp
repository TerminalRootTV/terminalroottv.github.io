#pragma once

#include <iostream>
#include <fstream>
#include <algorithm>
#include <filesystem>
#include <memory>

class ProPP {

  const std::string title;

  std::string header_file, cpp_file, 
        main_file, build_file,
        classname, filename;

  std::filesystem::path dir;

  std::filesystem::path path_header, path_cpp, 
    path_main, path_build;

  const std::string str_to_lower(const std::string& str);
  bool has_space(const std::string& str);
  void change_space(std::string& str, const std::string& c);
  bool can_create(const std::filesystem::path& dir);

  void set_files();

  public:
    ProPP(int const argc, char* const* argv);
    void run();
};
